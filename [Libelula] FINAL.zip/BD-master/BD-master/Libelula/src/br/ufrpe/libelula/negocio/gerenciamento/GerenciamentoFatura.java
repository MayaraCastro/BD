package br.ufrpe.libelula.negocio.gerenciamento;

public class GerenciamentoFatura {

}
