package br.ufrpe.libelula.exceptions;

public class InformacaoEmBrancoException extends Exception{
	private static final long serialVersionUID = 1L;

		public InformacaoEmBrancoException() {
			super("É preciso preencher todos as informações");
		}
}
