package br.ufrpe.libelula.testes;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Calendar;

import br.ufrpe.libelula.negocio.beans.Pacote;
import br.ufrpe.libelula.negocio.gerenciamento.Fachada;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;

public class Teste {
	public static void main(String[] args) {


	}
}
