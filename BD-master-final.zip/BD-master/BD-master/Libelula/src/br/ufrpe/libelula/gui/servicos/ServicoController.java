package br.ufrpe.libelula.gui.servicos;

import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;


import br.ufrpe.libelula.gui.ScreenManager;
import br.ufrpe.libelula.gui.pacote.PacoteController;
import br.ufrpe.libelula.negocio.beans.ItemPacote;
import br.ufrpe.libelula.negocio.beans.Servico_Ref;
import br.ufrpe.libelula.negocio.gerenciamento.Fachada;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class ServicoController implements Initializable{
	private Fachada f;

	private static Servico_Ref s;

   @FXML
   private static TableView<Servico_Ref> ListaServico;

   @FXML
   private ComboBox<String> tipoServico;


   @FXML
   private Button adicionar_itens;

   @FXML
   private Label codigo;

    @FXML
    private Button remover_button;

    @FXML
    private TextField valor;

    @FXML
    private TextField niveLabel;

    @FXML
    private TextField local_destino;


    @FXML
    private TextField Busca_Servico;

    @FXML
    private TableColumn<Servico_Ref, Integer> id_col;

    @FXML
    private TableColumn<Servico_Ref, Float> valor_col;

    @FXML
    private TableColumn<Servico_Ref, String> local_destino_col;

    @FXML
    private TableColumn<Servico_Ref, Integer> nivel_col;

    @FXML
    private TableColumn<Servico_Ref, Integer> tipo_col;


    @FXML
    void novo(ActionEvent event) {
    	s = new Servico_Ref();
    	codigo.setText("#");;
		valor.clear();
		local_destino.clear();
		niveLabel.clear();

		SingleSelectionModel<String> a =tipoServico.getSelectionModel() ;
		a.clearSelection();
		tipoServico.setSelectionModel(a);

		//adicionar_itens.setDisable(true);
		remover_button.setDisable(true);
    }

    @FXML
    void Tela_Principal(ActionEvent event) {
    	s = null;
    	ScreenManager.getInstance().showMenuPrincipal();
    }

    @FXML
    void buscar_servico(ActionEvent event) {
    	s = this.f.BuscarServico(Integer.parseInt(Busca_Servico.getText()));


    	if(s != null) {
    		codigo.setText(Integer.toString(s.getCodigo()));
    		valor.setText(Float.toString(s.getValor()));
    		local_destino.setText(s.getLocal_destino());
    		niveLabel.setText(Integer.toString(s.getNivel()));

    		if(s.getTipoServico()==0){
    			SingleSelectionModel<String> a =tipoServico.getSelectionModel() ;
        		a.select(0);
        		tipoServico.setSelectionModel(a);
    		}
    		else{
    			SingleSelectionModel<String> a =tipoServico.getSelectionModel() ;
        		a.select(1);
        		tipoServico.setSelectionModel(a);
    		}


    		ObservableList<Servico_Ref> oListItens = FXCollections.observableArrayList(this.f.ListarServico());
            ListaServico.setItems(oListItens);

            adicionar_itens.setDisable(false);
    		remover_button.setDisable(false);

    	}
    }

    @FXML
    void cancelar(ActionEvent event) {
    	ScreenManager.getInstance().fecharInfoStage();
    }

    public boolean verificarDados() {
    	if(codigo.getText() == null || local_destino == null || valor.getText() == null ||
    			niveLabel.getText() == null) {
    		return false;
    	}

    	if(Integer.parseInt(valor.getText()) <0 || Integer.parseInt(niveLabel.getText()) <0 ) {
    		return false;
    	}

    	return true;
    }

    @FXML
    void salvar(ActionEvent event) {
    	try {

	    	this.s.setCodigo(ServicoController.getServico().getCodigo());
	    	this.s.setValor(Float.parseFloat(valor.getText()));
	    	this.s.setLocal_destino(local_destino.getText());
	    	this.s.setNivel(Integer.parseInt(niveLabel.getText()));
	    	if(tipoServico.getSelectionModel().getSelectedItem().equals("Proprio")){
				this.s.setTipoServico(0);
			}
			else{
				this.s.setTipoServico(1);
			}

	    	if(this.verificarDados()) {
	    		if(s.getCodigo() != 0) {
	    			f.AtualizarServico(s);
	    			}else {
	    			f.CadastrarServico(s);
	    		}
	    		ScreenManager.getInstance().fecharInfoStage();
			}else {
				JOptionPane.showMessageDialog(null, "Informa��o Inv�lida!");
			}
	    	PacoteController.setItem(new ItemPacote());
    	}
    	catch(Exception e) {
    		JOptionPane.showMessageDialog(null, "Informa��o Inv�lida!" +e.getMessage());
    	}

    }

    private static Servico_Ref getServico() {
		// TODO Auto-generated method stub
		return s;
	}

	@FXML
    void remover(ActionEvent event) {
    	this.s.setCodigo(PacoteController.getPacote().getCodigo());
    	this.s.setValor(Float.parseFloat(valor.getText()));
    	this.s.setLocal_destino(local_destino.getText());
    	this.s.setNivel(Integer.parseInt(niveLabel.getText()));
    	if(tipoServico.getSelectionModel().getSelectedItem().equals("Proprio")){
			this.s.setTipoServico(0);
		}
		else{
			this.s.setTipoServico(1);
		}

    	if(s.getCodigo()!= 0) {
    		f.RemoverServico(s);
    		ScreenManager.getInstance().fecharInfoStage();
    	}

    }


	public void preenchercamposservico() {
		//servico

		this.s.setCodigo(PacoteController.getPacote().getCodigo());
    	this.s.setValor(Float.parseFloat(valor.getText()));
    	this.s.setLocal_destino(local_destino.getText());
    	this.s.setNivel(Integer.parseInt(niveLabel.getText()));
    	if(tipoServico.getSelectionModel().getSelectedItem().equals("Proprio")){
			this.s.setTipoServico(0);
		}
		else{
			s.setTipoServico(1);
		}

		codigo.setText(Integer.toString(s.getCodigo()));
		valor.setText(Float.toString(s.getValor()));
		local_destino.setText(s.getLocal_destino());

		niveLabel.setText(Integer.toString(s.getNivel()));

    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		ObservableList<String> ListaServico = FXCollections.observableArrayList("Proprio","Outra empresa");
		tipoServico.setItems(ListaServico);


		this.f = Fachada.getInstance();
		s = new Servico_Ref();


	}

	@FXML
    void selecionaitem(MouseEvent event) {
    	if(s !=null) {
			ObservableList<Servico_Ref> oListItens = FXCollections.observableArrayList(f.ListarServico());
    		ListaServico.setItems(oListItens);
		}
    	ServicoController.setItem(ListaServico.getSelectionModel().getSelectedItem());
    	if(PacoteController.getItem()!=null) {
    		    	ScreenManager.getInstance().showItem();
    	}
    	if(s !=null) {
			ObservableList<Servico_Ref> oListItens = FXCollections.observableArrayList(f.ListarServico());
    		ListaServico.setItems(oListItens);
		}
    }

	private static void setItem(Servico_Ref selectedItem) {
		ServicoController.setItem(selectedItem);
	}

	@FXML
    void adicionar_itens(ActionEvent event) {
    	ServicoController.setItem(new Servico_Ref());
    	ScreenManager.getInstance().showItem();
    	if(s !=null) {
			ObservableList<Servico_Ref> oListItens = FXCollections.observableArrayList(f.ListarServico());
    		ListaServico.setItems(oListItens);
		}
    }

	 @FXML
	    void remover_Servico(ActionEvent event) {
		 f.RemoverServico(s);;
	  }


	@FXML
    void Modificar_item(ActionEvent event) {
    	ServicoController.setItem(ListaServico.getSelectionModel().getSelectedItem());
    	ScreenManager.getInstance().showItem();
    	if(s !=null) {
			ObservableList<Servico_Ref> oListItens = FXCollections.observableArrayList(f.ListarServico());
    		ListaServico.setItems(oListItens);
		}

    }
}