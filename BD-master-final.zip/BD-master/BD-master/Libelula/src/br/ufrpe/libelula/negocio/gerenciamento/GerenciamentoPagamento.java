package br.ufrpe.libelula.negocio.gerenciamento;

import java.util.ArrayList;

import br.ufrpe.libelula.DAO.PacoteDAO;
import br.ufrpe.libelula.DAO.PagamentoDAO;
import br.ufrpe.libelula.negocio.beans.ItemPacote;
import br.ufrpe.libelula.negocio.beans.Pacote;
import br.ufrpe.libelula.negocio.beans.Pagamento;

public class GerenciamentoPagamento {

private PagamentoDAO pagamento;

	public GerenciamentoPagamento() {
		this.pagamento = new PagamentoDAO();
	}

	public void CadastrarPagamento(Pagamento a) {
			try {
				pagamento.inserir(a);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	public void RemoverPagamento(Pagamento a) {
		try {
			pagamento.remover(a);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Pagamento BuscarPagamento(int cod) {
		try {
			return pagamento.buscar(cod);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void AtualizarPagamento(Pagamento a) {
		try {
			pagamento.alterar(a);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Pagamento> ListarPagamento(){
		try {
			return this.pagamento.listarTodos();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int pegarCoddoUltimoInserido() {
		try {
			return pagamento.pegarCodigodoUltimoAutoIncrmente();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}



}
