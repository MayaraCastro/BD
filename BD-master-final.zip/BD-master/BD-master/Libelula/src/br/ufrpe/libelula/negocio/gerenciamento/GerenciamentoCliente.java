package br.ufrpe.libelula.negocio.gerenciamento;

import java.util.ArrayList;

import br.ufrpe.libelula.DAO.ClienteFisicoDAO;
import br.ufrpe.libelula.DAO.ClienteJuridicoDAO;

import br.ufrpe.libelula.DAO.PessoaDAO;

import br.ufrpe.libelula.negocio.beans.ClienteFisico;
import br.ufrpe.libelula.negocio.beans.ClienteJuridico;

import br.ufrpe.libelula.negocio.beans.Pessoa;

public class GerenciamentoCliente {
	private ClienteFisicoDAO fisico;
	private ClienteJuridicoDAO juridico;
	private PessoaDAO pessoa;

	public GerenciamentoCliente() {
		this.fisico = new ClienteFisicoDAO();
		this.juridico = new  ClienteJuridicoDAO();
		this.pessoa = new PessoaDAO();

	}

	public void CadastrarCliente(Pessoa a) {
			try {
				pessoa.inserir(a);
				a.setCod(pessoa.pegarCodigodoUltimoAutoIncrmente());
				if(a instanceof ClienteFisico) {
					fisico.inserir(((ClienteFisico)a));
				}else if(a instanceof ClienteJuridico){
					juridico.inserir(((ClienteJuridico)a));
				}


			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	public void RemoverCliente(Pessoa a) {
		try {

			if(a instanceof ClienteFisico) {
				fisico.inserir(((ClienteFisico)a));
			}else if(a instanceof ClienteJuridico){
				juridico.inserir(((ClienteJuridico)a));
			}


			pessoa.remover(a);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Pessoa BuscarCliente(int cod) {
		try {
				Pessoa p = pessoa.buscar(cod);
				ClienteFisico cf;
				ClienteJuridico cj;

				if(p !=null) {
					cf = fisico.buscar(cod);
					if(cf != null) {
						cf = new ClienteFisico(p.getCod(), p.getNome(), p.getDt_nasc(), p.getSexo(), p.getFone(), p.getFoto(), p.getCep(), p.getNum(),
								cf.getCodigo(), cf.getAgencia(), cf.getCPF(), cf.getTipo());
							return cf;
					}

					cj = juridico.buscar(cod);
					if(cj != null) {
						cj = new ClienteJuridico(p.getCod(), p.getNome(), p.getDt_nasc(), p.getSexo(), p.getFone(), p.getFoto(), p.getCep(), p.getNum(),
								cj.getCodigo(), cj.getAgencia(), cj.getCNPJ(), cj.getNome_Fantasia());
						return cj;
					}
				}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void AtualizarCliente(Pessoa a) {
		try {
			pessoa.alterar(a);
			if(a instanceof ClienteFisico) {
				fisico.inserir(((ClienteFisico)a));
			}else if(a instanceof ClienteJuridico){
				juridico.inserir(((ClienteJuridico)a));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Pessoa> ListarCliente(){
		return null;
	}

}